import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private service: UserService) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group(
      {
        firstName: ['', Validators.required,Validators.pattern("[a-zA-Z]")],
        lastName: ['', Validators.required,Validators.pattern("[a-zA-Z]")],
        password: ['', Validators.required,Validators.pattern("/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/")],
        email: ['', [Validators.required, Validators.email]],
        phone: ['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        role: ['',[Validators.required]]
      
      },
  
    );
  }

  

  onSubmit() {
    this.service.register(this.registerForm.getRawValue()).subscribe(data=>{
      console.log("registered successfully");
      alert("Registered Successfully !");
    })

    }

  onReset() {
    this.submitted = false;
    this.registerForm.reset();
  }
}
