export class Property{
    id: number;
    property_name: string;
    place: string;
    area: string;
    bhk_no: number;
    nearby_hospitals: number;
    nearby_schools: number;
    seller_id: number;
}