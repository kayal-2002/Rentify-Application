import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import { Property } from '../model/property.model';
import { CommonModule } from '@angular/common';
import { UserAuthService } from '../_services/user-auth.service';

@Component({
  selector: 'app-buyer',
  templateUrl: './buyer.component.html',
  styleUrls: ['./buyer.component.css']
})
export class BuyerComponent implements OnInit {

properties: Array<Property>;

constructor(private service: UserService,private router: Router,private userauthserive: UserAuthService) {}

  ngOnInit() {
    this.getAllProperties();
  }
  getAllProperties() {
    this.service.getProperties().subscribe(data=>{
      console.log(data);
      this.properties=data;
    },error=>{
      console.log(error)
    })

    
  }
  getSellerDetails(){
    this.router.navigate(["/details",this.userauthserive.getId()]);
  }

  
}
