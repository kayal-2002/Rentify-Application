import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ForbiddenComponent } from './forbidden/forbidden.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';

import { AuthGuard } from './_auth/auth.guard';
import { BuyerComponent } from './Buyer/buyer.component';
import { SellerComponent } from './Seller/seller.component';
import { DetailsComponent } from './Details/details.component';
import { UpdateComponent } from './Update/update.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'seller', component: SellerComponent, canActivate:[AuthGuard], data:{roles:"Seller"} },
  { path: 'buyer', component: BuyerComponent ,  canActivate:[AuthGuard], data:{roles:"Buyer"} },
  { path: 'login', component: LoginComponent },
  { path: 'details/:id', component: DetailsComponent, canActivate:[AuthGuard], data:{roles:"Buyer"} },
  { path: 'update/:id', component: UpdateComponent, canActivate:[AuthGuard], data:{roles:"Seller"} },

  { path: 'forbidden', component: ForbiddenComponent },
  {path:"",component:HomeComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
