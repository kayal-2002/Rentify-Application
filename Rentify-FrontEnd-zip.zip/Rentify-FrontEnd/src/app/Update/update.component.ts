import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import { ActivatedRoute } from '@angular/router';
import { User } from '../model/User.model';
import { Property } from '../model/property.model';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class UpdateComponent implements OnInit {

  propertyid: number;
  property: Property

  constructor(private route: ActivatedRoute,private service: UserService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.propertyid = params['id']; // Access the 'id' parameter from the URL
      this.getDetails();
    });
  }
 getDetails(){
  this.service.getPropertyForUpdate(this.propertyid).subscribe(data=>{
    this.property=data;
  },error=>{
    console.log(error)
  })
 }

}
