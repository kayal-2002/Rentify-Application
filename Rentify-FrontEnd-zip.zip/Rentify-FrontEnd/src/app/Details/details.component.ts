import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import { ActivatedRoute } from '@angular/router';
import { User } from '../model/User.model';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class DetailsComponent implements OnInit {

  sellerid: number;
  user: User

  constructor(private route: ActivatedRoute,private service: UserService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.sellerid = params['id']; // Access the 'id' parameter from the URL
      this.getDetails();
    });
  }
 getDetails(){
  this.service.getSellerDetails(this.sellerid).subscribe(data=>{
    this.user=data;
  },error=>{
    console.log(error)
  })
 }

}
