import { Component, OnInit } from '@angular/core';
import { UserAuthService } from '../_services/user-auth.service';
import { UserService } from '../_services/user.service';
import { Property } from '../model/property.model';

@Component({
  selector: 'app-buyer',
  templateUrl: './buyer.component.html',
  styleUrls: ['./buyer.component.css']
})
export class SellerComponent implements OnInit {

 properties: Array<Property>;

  constructor(private router: Router, private userauthservice: UserAuthService,private service: UserService) {}

  ngOnInit() {
    this.getAllProperties();
  }
  getAllProperties(){
    this.service.getPropertiesForSeller(this.userauthservice.getId()).subscribe(data=>{
      this.properties=data;
    },error=>{
      console.log(error)
    })

  }

  updateProperty(id: number){
    this.router.navigate(["/update",id]);
  }
 
  deleteProperty(id: number){
    this.service.deleteProperty(id).subscribe(data=>{
      alert("deleted !")
    },error=>{
      console.log(error)
    })
  }
  
}
