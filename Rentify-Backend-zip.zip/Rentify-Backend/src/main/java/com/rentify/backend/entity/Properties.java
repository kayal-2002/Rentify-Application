package com.rentify.backend.entity;



import javax.persistence.*;
import java.util.Set;

@Entity
public class Properties{

    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private int id;
    private String property_name;
   private String place;
   private String area;
   private int bhk_no;
   private int nearby_hospitals;
   private int nearby_schools;
   private int seller_id;

    public String getProperty_name() {
        return property_name;
    }

    public void setProperty_name(String property_name) {
        this.property_name = property_name;
    }

    public int getSeller_id() {
        return seller_id;
    }

    public void setSeller_id(int seller_id) {
        this.seller_id = seller_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public int getBhk_no() {
        return bhk_no;
    }

    public void setBhk_no(int bhk_no) {
        this.bhk_no = bhk_no;
    }

    public int getNearby_hospitals() {
        return nearby_hospitals;
    }

    public void setNearby_hospitals(int nearby_hospitals) {
        this.nearby_hospitals = nearby_hospitals;
    }

    public int getNearby_schools() {
        return nearby_schools;
    }

    public void setNearby_schools(int nearby_schools) {
        this.nearby_schools = nearby_schools;
    }
}
