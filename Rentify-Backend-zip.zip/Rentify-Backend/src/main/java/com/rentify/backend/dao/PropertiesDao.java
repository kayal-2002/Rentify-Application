package com.rentify.backend.dao;

import com.rentify.backend.entity.Properties;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PropertiesDao extends JpaRepository<Properties,Integer> {

    @Query("select p from Properties p where seller_id=?1")
    List<Properties> findAllForSeller(int id);
}
