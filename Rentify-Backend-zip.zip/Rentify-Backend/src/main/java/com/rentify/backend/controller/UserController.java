package com.rentify.backend.controller;

import com.rentify.backend.dao.PropertiesDao;
import com.rentify.backend.dao.UserDao;
import com.rentify.backend.entity.Properties;
import com.rentify.backend.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserDao userService;
    @Autowired
    private PropertiesDao prepo;



    @PostMapping({"/registerNewUser"})
    public User registerNewUser(@RequestBody User user) {
        return userService.save(user);
    }

    @PostMapping({"/postProperty/{id}"})
    public Properties save(@RequestBody Properties property,@RequestParam("id") int id) {
        property.setSeller_id(id);
        return prepo.save(property);
    }



    @GetMapping({"/getProperties"})
    @PreAuthorize("hasRole('Buyer')")
    public List<Properties> getallproperties(){
        return prepo.findAll();
    }
    @GetMapping("/getProperty/{id}")
    @PreAuthorize("hasRole('Seller')")
    public Properties getProperty(@RequestParam("id") int id){
        return prepo.findById(id).orElseThrow(()->new RuntimeException("property does not exists"));
    }
    @GetMapping({"/getProperties/{id}"})
    @PreAuthorize("hasRole('Seller')")
    public List<Properties> getallpropertiesforSeller(@RequestParam("id") int id) {
        return prepo.findAllForSeller(id);
    }
    @GetMapping({"/updateProperty/{id}"})
    @PreAuthorize("hasRole('Seller')")
    public Properties update(@RequestParam int id, @RequestBody Properties property){
        Properties old_property = prepo.findById(id).orElseThrow(()-> new RuntimeException("property not exists"));
        old_property.setArea(property.getArea());
        old_property.setBhk_no(property.getBhk_no());
        old_property.setPlace(property.getPlace());
        old_property.setNearby_schools(property.getNearby_schools());
        old_property.setNearby_hospitals(property.getNearby_hospitals());
        return prepo.save(old_property);


    }
   @DeleteMapping("/deleteProperty/{id}")
   @PreAuthorize("hasRole('Seller')")
    public void deleteProperty(@RequestParam("id") int id){
       Properties property = prepo.findById(id).orElseThrow(()-> new RuntimeException("property not exists"));
       prepo.delete(property);
   }

   @GetMapping("/getSellerDetails/{id}")
   @PreAuthorize("hasRole('Buyer')")
    public User seeSellerDetails(@RequestParam("id") int id){
       Properties property = prepo.findById(id).orElseThrow(()-> new RuntimeException("property not exists"));
       User seller = userService.findById(String.valueOf((int)property.getSeller_id())).orElseThrow(()->new RuntimeException("user not exists"));
       return seller;

   }



}
